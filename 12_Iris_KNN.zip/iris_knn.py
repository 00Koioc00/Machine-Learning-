# Python implementation of 12 Iris KNN

