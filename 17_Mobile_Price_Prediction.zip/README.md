# 17 Mobile Price Prediction

This folder contains the implementation of the **17 Mobile Price Prediction** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python mobile_price_prediction.py
   ```
