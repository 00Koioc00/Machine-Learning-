# 8 Linear Regression

This folder contains the implementation of the **8 Linear Regression** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python linear_regression.py
   ```
