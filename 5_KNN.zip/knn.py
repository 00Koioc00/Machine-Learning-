# Python implementation of 5 KNN

