# 2 Candidate Elimination

This folder contains the implementation of the **2 Candidate Elimination** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python candidate_elimination.py
   ```
