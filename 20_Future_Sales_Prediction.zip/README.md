# 20 Future Sales Prediction

This folder contains the implementation of the **20 Future Sales Prediction** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python future_sales_prediction.py
   ```
