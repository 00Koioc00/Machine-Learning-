# 15 Iris Naive Bayes

This folder contains the implementation of the **15 Iris Naive Bayes** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python iris_naive_bayes.py
   ```
