# Python implementation of 15 Iris Naive Bayes

