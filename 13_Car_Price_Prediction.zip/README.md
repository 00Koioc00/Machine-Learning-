# 13 Car Price Prediction

This folder contains the implementation of the **13 Car Price Prediction** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python car_price_prediction.py
   ```
