# 16 Compare Classification Algorithms

This folder contains the implementation of the **16 Compare Classification Algorithms** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python compare_classifiers.py
   ```
