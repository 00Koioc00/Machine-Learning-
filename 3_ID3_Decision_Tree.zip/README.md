# 3 ID3 Decision Tree

This folder contains the implementation of the **3 ID3 Decision Tree** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python id3_decision_tree.py
   ```
