# 18 Perceptron IRIS

This folder contains the implementation of the **18 Perceptron IRIS** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python perceptron_iris.py
   ```
