This is the implementation of Naive Bayes Iris Classification.
