# 11 Credit Score Classification

This folder contains the implementation of the **11 Credit Score Classification** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python credit_score_classification.py
   ```
