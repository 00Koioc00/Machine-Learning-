# 9 Compare Linear vs Polynomial

This folder contains the implementation of the **9 Compare Linear vs Polynomial** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python compare_regression.py
   ```
