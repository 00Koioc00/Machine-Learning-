# 4 ANN Backpropagation

This folder contains the implementation of the **4 ANN Backpropagation** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python backpropagation_ann.py
   ```
