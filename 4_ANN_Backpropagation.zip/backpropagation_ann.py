# Python implementation of 4 ANN Backpropagation

