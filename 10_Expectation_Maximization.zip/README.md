# 10 Expectation Maximization

This folder contains the implementation of the **10 Expectation Maximization** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python em_algorithm.py
   ```
