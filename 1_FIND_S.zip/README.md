# 1 FIND S

This folder contains the implementation of the **1 FIND S** in Python.

## Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the program:
   ```
   python find_s.py
   ```
