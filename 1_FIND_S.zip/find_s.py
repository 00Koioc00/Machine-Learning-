# Python implementation of 1 FIND S

