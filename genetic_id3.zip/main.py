
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import random

# Genetic Algorithm for Feature Selection
def genetic_algorithm(X, y, generations=10, population_size=10):
    def initialize_population():
        return [np.random.randint(0, 2, X.shape[1]).tolist() for _ in range(population_size)]

    def fitness(individual):
        selected_features = [i for i in range(len(individual)) if individual[i] == 1]
        if not selected_features:
            return 0
        clf = DecisionTreeClassifier(criterion='entropy')
        clf.fit(X_train[:, selected_features], y_train)
        preds = clf.predict(X_test[:, selected_features])
        return accuracy_score(y_test, preds)

    def crossover(parent1, parent2):
        point = random.randint(1, len(parent1) - 1)
        return parent1[:point] + parent2[point:]

    def mutate(individual, mutation_rate=0.01):
        return [1 - gene if random.random() < mutation_rate else gene for gene in individual]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
    population = initialize_population()

    for _ in range(generations):
        scores = [(ind, fitness(ind)) for ind in population]
        scores.sort(key=lambda x: x[1], reverse=True)
        population = [x[0] for x in scores[:population_size // 2]]

        new_population = []
        while len(new_population) < population_size:
            parents = random.sample(population, 2)
            child = mutate(crossover(*parents))
            new_population.append(child)
        population = new_population

    best_solution = max(population, key=lambda ind: fitness(ind))
    return best_solution

# Load dataset
df = pd.read_csv('https://raw.githubusercontent.com/jbrownlee/Datasets/master/iris.csv', header=None)
X = df.iloc[:, :-1].values
y = LabelEncoder().fit_transform(df.iloc[:, -1])

best_features = genetic_algorithm(X, y)
print("Selected Features:", best_features)
