# Genetic Algorithm with ID3

## Description
This project implements genetic algorithm with id3 using Python and popular machine learning libraries.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the project:
   ```bash
   python main.py
   ```

## Dataset
Dataset is automatically downloaded from an online source in the script.

## Files
- `main.py` - Main implementation
- `requirements.txt` - Python dependencies
- `.gitignore` - Common Python ignores
- `README.md` - Project overview
