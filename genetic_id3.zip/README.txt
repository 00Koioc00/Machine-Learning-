This is the implementation of Genetic Algorithm with ID3.
