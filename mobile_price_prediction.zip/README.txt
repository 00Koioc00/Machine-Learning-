This is the implementation of Mobile Price Prediction.
