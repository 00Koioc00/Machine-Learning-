# Python implementation of 19 Bank Loan Naive Bayes

