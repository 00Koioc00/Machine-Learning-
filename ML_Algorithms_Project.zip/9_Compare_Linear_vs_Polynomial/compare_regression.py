# Python implementation of 9 Compare Linear vs Polynomial

