# Python implementation of 6 Naive Bayes

