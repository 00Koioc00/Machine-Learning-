# Python implementation of 2 Candidate Elimination

