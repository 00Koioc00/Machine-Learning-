# Python implementation of 10 Expectation Maximization

