# Machine Learning Algorithm Implementations

This repository contains Python implementations of various fundamental machine learning algorithms.

## List of Implemented Algorithms

1. FIND-S Algorithm
2. Candidate-Elimination Algorithm
3. ID3 Decision Tree Algorithm
4. Artificial Neural Network using Backpropagation
5. K-Nearest Neighbours (KNN)
6. Naïve Bayes Classifier
7. Logistic Regression
8. Linear Regression
9. Comparison of Linear and Polynomial Regression
10. Expectation-Maximization Algorithm

## Setup Instructions

1. Create a virtual environment (optional but recommended):
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use: venv\Scripts\activate
   ```

2. Install required packages:
   ```
   pip install -r requirements.txt
   ```

3. Run any program:
   ```
   python <program_file>.py
   ```

## Requirements

Required packages are listed in `requirements.txt`.

## Directory Structure

Each algorithm has a dedicated folder containing the source code.

