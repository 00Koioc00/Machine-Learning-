# Python implementation of 3 ID3 Decision Tree

